# Getting started

Nested worker import reached the browser.
