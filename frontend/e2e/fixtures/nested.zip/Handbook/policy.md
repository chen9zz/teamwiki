# Policy

Synthetic import policy.
