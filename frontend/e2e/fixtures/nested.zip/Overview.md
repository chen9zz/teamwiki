# Overview

Synthetic ZIP fixture.
